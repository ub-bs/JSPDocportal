package sqltree.draw;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.LineBorder;
import org.eclipse.draw2d.ToolbarLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;

public class NodeFigure extends Figure{
	  public static Color nodeColor = new Color(null,255,255,206);
	  public static Color numberColor = new Color(null, 50,100,200);
	  public static Font numberFont = new Font(null, "Courier", 10, SWT.NORMAL);
	  private Label lblLeft, lblRight, lblName;
	public NodeFigure(){  
		ToolbarLayout layout = new ToolbarLayout(true);
	    setLayoutManager(layout);	
	    setBorder(new LineBorder(ColorConstants.black,1));
	    setBackgroundColor(nodeColor);
	    setOpaque(true);
	    lblLeft = new Label();
	    lblLeft.setForegroundColor(numberColor);
	    lblLeft.setFont(numberFont);
	    lblName=new Label();
	    lblRight = new Label();
	    lblRight.setForegroundColor(numberColor);
	    lblRight.setFont(numberFont);
	    add(lblLeft);
	    add(lblName);
	    add(lblRight);
	}
	
	public void setLeft(int x){
		lblLeft.setText(Integer.toString(x)+"  ");
	}
	
	public int getLeft(){
		return Integer.parseInt(lblLeft.getText().trim());
	}
	public void setRight(int x){
		lblRight.setText("  "+Integer.toString(x));
	}
	
	public void setName(String s){
		lblName.setText(s);
	}
	  
	    
}
