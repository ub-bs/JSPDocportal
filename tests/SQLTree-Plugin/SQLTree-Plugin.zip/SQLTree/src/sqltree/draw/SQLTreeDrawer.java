package sqltree.draw;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Hashtable;

import org.eclipse.draw2d.ChopboxAnchor;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.LayoutManager;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.draw2d.graph.DirectedGraph;
import org.eclipse.draw2d.graph.DirectedGraphLayout;
import org.eclipse.draw2d.graph.Edge;
import org.eclipse.draw2d.graph.Node;

import sqltree.SQLTree;

public class SQLTreeDrawer {
	public static void draw(SQLTree tree, Figure contents){
		Connection conn = tree.openConnection();
		contents.removeAll();
		contents.setLayoutManager(new XYLayout());
		Hashtable<String, NodeFigure> nodelist = new Hashtable<String, NodeFigure>();
		Hashtable<NodeFigure, NodeFigure> parents = new Hashtable<NodeFigure, NodeFigure>();
		try {
			Statement s = conn.createStatement();
			Statement s1 = conn.createStatement();
			
			ResultSet rs = s.executeQuery("select * from sqltree");
			while (rs.next()) {
				NodeFigure node = new NodeFigure();
				node.setName(rs.getString(1));
				node.setLeft(rs.getInt(2));
				node.setRight(rs.getInt(3));
				contents.add(node);
				nodelist.put(rs.getString(1), node);
				contents.getLayoutManager().setConstraint(node, new Rectangle(1, 1, -1, -1));
				
			}

			rs.close();
			//Connections
			contents.getLayoutManager().layout(contents);
			ResultSet rs1 = s.executeQuery("select * from sqltree");
			
			while(rs1.next()){
				String nodename=rs1.getString(1);	
				//get parent ...
				ResultSet rsParent = s1.executeQuery("select name from sqltree where "+ rs1.getInt(2) +">leftval and "+rs1.getInt(3)+"<rightval order by leftval desc");
		
				if(rsParent.next()){

					String parentName = rsParent.getString(1);
					PolylineConnection c = new PolylineConnection();
					ChopboxAnchor sourceAnchor = new ChopboxAnchor(nodelist.get(parentName));
					ChopboxAnchor targetAnchor = new ChopboxAnchor(nodelist.get(nodename));
					c.setSourceAnchor(sourceAnchor);
					c.setTargetAnchor(targetAnchor);
					parents.put(nodelist.get(nodename), nodelist.get(parentName));	
					contents.add(c);
					
				}
				rsParent.close();
				
			}
			layout(nodelist, parents, contents.getLayoutManager());
			rs.close();
			s.close();
			s1.close();
			conn.commit();
			conn.close();
			
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	private static void layout(Hashtable<String, NodeFigure> nodefigures, Hashtable<NodeFigure, NodeFigure> parents, LayoutManager layout){
		if(nodefigures.size()==0){ return;}
		HashMap<NodeFigure, Node> nodeMap = new HashMap<NodeFigure, Node>();
		DirectedGraph diGraph = new DirectedGraph();
		for (NodeFigure nf:nodefigures.values()){
			Node n = new Node();
			diGraph.nodes.add(n);
			nodeMap.put(nf, n);
			
			n.height = nf.getSize().height;
			n.width = nf.getSize().width;	
			n.setRowConstraint(nf.getLeft());
		}
		
		
		for (NodeFigure nf:nodefigures.values()){
			if (parents.containsKey(nf)){
				NodeFigure nfParent = parents.get(nf);
				Edge e = new Edge(nodeMap.get(parents.get(nf)), nodeMap.get(nf));
				diGraph.edges.add(e);
			}
		}
		
		DirectedGraphLayout dglayout = new DirectedGraphLayout();
		dglayout.visit(diGraph);
		
		//update model
		for (NodeFigure nf:nodefigures.values()){
			Node n = nodeMap.get(nf);
			layout.setConstraint(nf, new Rectangle(n.x, n.y, n.width, n.height));
			
		}

	}
}
