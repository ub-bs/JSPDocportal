package sqltree;

public class SQLTreeParser {
 //parses trees in list notation
//	e.g. [A[B[D]][C[E][F[H]][G]]]
//	each node has the structure: <node> =  [<label> <node>*]
//	                             <label> = java.lang.String
	                             
	                             
	public static void createFromFormula(SQLTree tree, String formula){
		
		if(!formula.startsWith("(") && !formula.endsWith(")")){
			System.out.println("Syntaxfehler in Formel");
		}
		doit(tree,formula,0);
		//
		//System.out.println(x);
	}
	
	private static int doit(SQLTree t, String s, int c){
		System.out.println(s);
		String name ="";
		String subtree="";
		int left = c;
		int start = c;
		int right =-1;
		int depth = -1;
		String x = s;
		for(int i=0;i<x.length();i++){
			String chr = s.substring(i,i+1);
			if(chr.equals("(")){
				depth++;
				if(depth>0){
					subtree+=chr;
					
				}
				else{
					left++;
				}
				continue;
			}
			
			if(chr.equals(")")){
				depth--;
				if(depth>-1){
					subtree+=chr;
				}
				if(depth==0){
					right = doit(t, subtree, left);
					subtree="";
					left = right;
					
					
				}
				continue;
			}

			if(depth==0){
				name=name+chr;
			}
			else{
				subtree+=chr;
			}
		}
		if (right==-1) right = left;
		t.insertOrUpdateNode(name, start, right);
		return right+1;
	}
	
	
	public static void main(String[] args){
		SQLTree tr = new SQLTree();
		createFromFormula(tr, "[A[B][C[D][E]]]");
		tr.debug();
		createFromFormula(tr, "[A[B][C][D][E][F][G]]");
		tr.debug();
		createFromFormula(tr, "[A[B[C[D[E[F[G]]]]]]]");
		tr.debug();
		createFromFormula(tr, "[A[B[D]][C[E][F[H]][G]]]");
		tr.debug();
	}
}
