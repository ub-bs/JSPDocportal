package sqltree;

public class SQLTREETest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		SQLTree tree = SQLTreeParser.parse("[A[B[D]][C[E][F[H]][G]]]");
//		tree.debug();
		
	//	SQLTreeOperations.delete(tree, "F");
		//SQLTreeOperations.move_after(tree, "B", "F");
		//SQLTreeOperationsFirstTry.move_after(tree, "F", "B");
//		SQLTreeOperations.move_before(tree, "B", "F");
		//  SQLTreeOperations.move_before(tree, "F", "B");
		//SQLTreeOperations.move_under(tree, "B", "E");
//		tree.debug();
		
		SQLTreeManager treeMgr= new SQLTreeManager();
		String s = "(A(B)(C(D)(E(G)(H(I)(K)(L)))(F)))";
		
		treeMgr.parse(s);
		System.out.println(s);
		System.out.println(treeMgr.getTreeAsListString());
		treeMgr.debug();
		//SQLTreeOperations.delete(tree, "E");
		//SQLTreeOperations.move_after(tree, "H", "B");
		//SQLTreeOperations.move_after(tree, "E", "B");
		//SQLTreeOperations.move_under(tree, "E", "F");
		treeMgr.move_after("H", "B");
		System.out.println(treeMgr.getTreeAsListString());
		treeMgr.debug();

	}

}
