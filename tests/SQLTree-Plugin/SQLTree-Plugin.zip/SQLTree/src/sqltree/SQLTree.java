package sqltree;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class SQLTree {
	//derby parameter
   // public String framework = "embedded";
   // public String driver = "org.apache.derby.jdbc.EmbeddedDriver";
   // public String protocol = "jdbc:derby:";
   // public String user="user1";
   //public String password="user1";	
    
   String driver="org.hsqldb.jdbcDriver";
   String protocol="jdbc:hsqldb:mem:";
   String user="sa";
   String password="";	
   
    
    
    public SQLTree(){
       		initTable();
   }

    public void insertOrUpdateNode(String name, int left, int right){
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from sqltree where name='"+name+"'");
			if(rs.next()){
				s.execute(
	                "update sqltree set leftval="+left+", rightval="+right+" where name='"+name+"'");
			}
			else{
				s.execute("insert into sqltree values ('"+name+"',"+left+","+right+")");
			}
			rs.close();
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public void updateLeft(String name, int left){
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from sqltree where name='"+name+"'");
			if(rs.next()){
				s.execute(
						"update sqltree set leftval="+left+" where name='"+name+"'");
			}
			else{
				s.execute("insert into sqltree values ('"+name+"',"+left+","+Integer.MIN_VALUE+")");
			}
			rs.close();
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public void updateRight(String name, int right){
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from sqltree where name='"+name+"'");
			if(rs.next()){
				s.execute(
						"update sqltree set rightval="+right+" where name='"+name+"'");
			}
			else{
				s.execute("insert into sqltree values ('"+name+"',"+Integer.MIN_VALUE+","+right+")");
			}
			rs.close();
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public int getLeft(String name){
		int result = Integer.MIN_VALUE;
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select leftval from sqltree where name='"+name+"'");
			
			while(rs.next()){
				result = rs.getInt(1);
			}
			
			rs.close();	
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return result;
	}
	
	public int getRight(String name){
		int result = Integer.MIN_VALUE;
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select rightval from sqltree where name='"+name+"'");
			
			while(rs.next()){
				result = rs.getInt(1);
			}
			
			rs.close();	
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return result;
	}
	
	public String getNameForLeft(int l){
		String result = null;
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select name from sqltree where leftval="+l);
			
			while(rs.next()){
				result = rs.getString(1);
			}
			
			rs.close();	
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return result;
	}
	public String getNameForRight(int r){
		String result = null;
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select name from sqltree where rightval="+r);
			
			while(rs.next()){
				result = rs.getString(1);
			}
			
			rs.close();	
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return result;
	}

	public void delete(String name){
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			s.execute("delete from sqltree where name='"+name+"'");
		
			s.close();
			conn.commit();
			conn.close();
			
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
	}
	
	public List<String>getNodeNames(){
		ArrayList<String> al = new ArrayList<String>();
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select name from sqltree order by name");
			
			while(rs.next()){
				al.add(rs.getString(1));
			}
			
			rs.close();	
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return al;
	}
	
	

	public void debug(){
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from sqltree order by name");
			System.out.println("SQLTREE:");
			while(rs.next()){
				System.out.println(rs.getString(1)+" : "+rs.getInt(2)+ " : "+rs.getInt(3));
			}
			
			rs.close();	
			s.close();
			conn.commit();
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public Connection openConnection(){
		try{
		Class.forName(driver).newInstance();
	//    System.out.println("Loaded the appropriate driver.");

	            Connection conn = null;
	            Properties props = new Properties();
	            props.put("user", user);
	            props.put("password", password);

	            /*
	               The connection specifies create=true to cause
	               the database to be created. To remove the database,
	               remove the directory derbyDB and its contents.
	               The directory derbyDB will be created under
	               the directory that the system property
	               derby.system.home points to, or the current
	               directory if derby.system.home is not set.
	             */
	            conn = DriverManager.getConnection(protocol +
	                    "derbyDB;create=true", props);

//	            System.out.println("Connected to and created database derbyDB");

	            conn.setAutoCommit(false);
	            return conn;
		}
		catch(IllegalAccessException e){
			e.printStackTrace();
			return null;
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
			return null;
		}
		catch(InstantiationException e){
			e.printStackTrace();
			return null;
		}
		catch(SQLException e){
			e.printStackTrace();
			return null;
		}
	}
	public void initTable(){
		try{
			Connection conn =openConnection(); 
			Statement s = conn.createStatement();
			 try {
		           s.executeUpdate("DROP TABLE sqltree");
		     } catch (SQLException e) {
		    	 //ignore
		     }
			s.execute("create table sqltree(name varchar(40), leftval int, rightval int)");
			s.close();
			conn.commit();
			conn.close();
			
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
}
