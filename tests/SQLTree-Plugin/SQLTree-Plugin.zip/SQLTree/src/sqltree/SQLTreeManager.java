package sqltree;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Stack;

public class SQLTreeManager {
	private SQLTree tree;
	public SQLTreeManager(){
			tree = new SQLTree();
	}
	
	public void parse(String formula){
		SQLTreeParser.createFromFormula(tree, formula);
	}
	
	
	public void delete(String name) {
		try {
			int left = Integer.MIN_VALUE;
			int right = Integer.MAX_VALUE;

			Connection conn = tree.openConnection();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select leftval from sqltree where name='"+ name + "'");
			if (rs.next()) {
				left = rs.getInt(1);
			}
			rs = s.executeQuery("select rightval from sqltree where name='"	+ name + "'");
			if (rs.next()) {
				right = rs.getInt(1);
			}
			int diff = right - left + 1;

			//delete
			s.execute("delete from sqltree where leftval>=" + left + " and leftval<" + right);

			// Numerierung
			s.executeUpdate("update sqltree set leftval = leftval - " + diff + " where leftval > " + left);
			s.executeUpdate("update sqltree set rightval = rightval - " + diff + " where rightval > " + left);

			s.close();
			conn.commit();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//implentiert wurde: "Einf�gen als letztes Kind", wenn schon Kinder vorhanden sind
	//eventuell braucht man noch ein "Einf�gen als erstes Kind"
	public void move_under(String what, String where){
		try {
			int where_left = Integer.MIN_VALUE;
			int where_right = Integer.MIN_VALUE;
			int what_left = Integer.MIN_VALUE;
			int what_right = Integer.MIN_VALUE;

			Connection conn = tree.openConnection();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select leftval from sqltree where name='"+ where + "'");
			if (rs.next()) {
				where_left = rs.getInt(1);
			}
			rs = s.executeQuery("select rightval from sqltree where name='"	+ where + "'");
			if (rs.next()) {
				where_right = rs.getInt(1);
			}
			rs = s.executeQuery("select leftval from sqltree where name='"+ what + "'");
			if (rs.next()) {
				what_left = rs.getInt(1);
			}
			rs = s.executeQuery("select rightval from sqltree where name='"	+ what + "'");
			if (rs.next()) {
				what_right = rs.getInt(1);
			}
			// neue Numerierung f�r jeden Knoten x...
			//x.left<min(what_left, where_left) bleibt
			//x.right>max(what_right, where_right) bleibt;

			//Sicherung des zu verschiebenden Teilbaums -> Multiplikation mit -1 (alternativ: Addition mit 1.000.000.000?)
			s.executeUpdate("update sqltree set leftval=leftval*-1, rightval=rightval*-1 where leftval>="+what_left+" and leftval<"+what_right);
						
			int diff = what_right-what_left+1;
//			Bestehende Knotennummern um diff verschieben
			if(what_right<where_right){ diff = diff*-1;}
				
			s.executeUpdate("update sqltree set leftval=leftval+"+diff+" where leftval>"+Math.min(what_right, where_right)+" and leftval<"+Math.max(what_right, where_right));
			s.executeUpdate("update sqltree set rightval=rightval+"+diff+" where rightval>="+Math.min(what_right, where_right)+" and rightval<"+Math.max(what_right, where_right));
			
			
				
						
			 rs = s.executeQuery("select rightval from sqltree where name='"+ where + "'");
			if (rs.next()) {
				where_right = rs.getInt(1);
			}
			
			//Knoten im Teilbaum Neusetzen
			s.executeUpdate("update sqltree set leftval=(leftval*-1)+"+  Integer.toString(where_right-1-(what_right))
					                        +", rightval=(rightval*-1)+"+Integer.toString(where_right-1-(what_right)) 
					                        +" where leftval<0");

			s.close();
			conn.commit();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public void move_after(String what, String where){
		try {
			int where_left = Integer.MIN_VALUE;
			int where_right = Integer.MIN_VALUE;
			int what_left = Integer.MIN_VALUE;
			int what_right = Integer.MIN_VALUE;

			Connection conn = tree.openConnection();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select leftval from sqltree where name='"+ where + "'");
			if (rs.next()) {
				where_left = rs.getInt(1);
			}
			rs = s.executeQuery("select rightval from sqltree where name='"	+ where + "'");
			if (rs.next()) {
				where_right = rs.getInt(1);
			}
			rs = s.executeQuery("select leftval from sqltree where name='"+ what + "'");
			if (rs.next()) {
				what_left = rs.getInt(1);
			}
			rs = s.executeQuery("select rightval from sqltree where name='"	+ what + "'");
			if (rs.next()) {
				what_right = rs.getInt(1);
			}
			// neue Numerierung f�r jeden Knoten x...
			//x.left<min(what_left, where_left) bleibt
			//x.right>max(what_right, where_right) bleibt;

			//Sicherung des zu verschiebenden Teilbaums -> Multiplikation mit -1 (alternativ: Addition mit 1.000.000.000?)
			s.executeUpdate("update sqltree set leftval=leftval*-1, rightval=rightval*-1 where leftval>="+what_left+" and leftval<"+what_right);
						
			int diff = what_right+1-what_left;
			if(what_right<where_right) diff = diff*-1;
//			Bestehende Knotennummern um diff verschieben

			s.executeUpdate("update sqltree set leftval=leftval+"+diff+" where leftval>"+Math.min(what_right, where_right)+" and leftval<="+Math.max(what_right, where_right));
		    s.executeUpdate("update sqltree set rightval=rightval+"+diff+" where rightval>"+Math.min(what_right, where_right)+" and rightval<="+Math.max(what_right, where_right));
			
	
			rs = s.executeQuery("select rightval from sqltree where name='"	+ where + "'");
			if (rs.next()) {
				where_right = rs.getInt(1);
			}
			//Knoten im Teilbaum Neusetzen
			s.executeUpdate("update sqltree set leftval=(leftval*-1)+"+Integer.toString(where_right+1-what_left)
													+", rightval=(rightval*-1)+"+Integer.toString(where_right+1-what_left) 
													+" where leftval<0");
			
			s.close();
			conn.commit();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	public void move_before(String what, String where){
		try {
			int where_left = Integer.MIN_VALUE;
			int where_right = Integer.MIN_VALUE;
			int what_left = Integer.MIN_VALUE;
			int what_right = Integer.MIN_VALUE;

			Connection conn = tree.openConnection();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select leftval from sqltree where name='"+ where + "'");
			if (rs.next()) {
				where_left = rs.getInt(1);
			}
			rs = s.executeQuery("select rightval from sqltree where name='"	+ where + "'");
			if (rs.next()) {
				where_right = rs.getInt(1);
			}
			rs = s.executeQuery("select leftval from sqltree where name='"+ what + "'");
			if (rs.next()) {
				what_left = rs.getInt(1);
			}
			rs = s.executeQuery("select rightval from sqltree where name='"	+ what + "'");
			if (rs.next()) {
				what_right = rs.getInt(1);
			}
			// neue Numerierung f�r jeden Knoten x...
			//x.left<min(what_left, where_left) bleibt
			//x.right>max(what_right, where_right) bleibt;

			//Sicherung des zu verschiebenden Teilbaums -> Multiplikation mit -1 (alternativ: Addition mit 1.000.000.000?)
			s.executeUpdate("update sqltree set leftval=leftval*-1, rightval=rightval*-1 where leftval>="+what_left+" and leftval<"+what_right);
						
			int diff = what_right-what_left+1;
//			Bestehende Knotennummern um diff verschieben
			if(what_left<where_left) diff = diff*-1;
			s.executeUpdate("update sqltree set leftval=leftval + "+diff+" where leftval>="+Math.min(what_left, where_left)+" and leftval<"+Math.max(what_left, where_left));
		    s.executeUpdate("update sqltree set rightval=rightval + "+diff+" where rightval>="+Math.min(what_left, where_left)+" and rightval<"+Math.max(what_left, where_left));

		    rs = s.executeQuery("select leftval from sqltree where name='"+ where + "'");
			if (rs.next()) {
				where_left = rs.getInt(1);
			}
					    
			//Knoten im Teilbaum Neusetzen
			
			s.executeUpdate("update sqltree set leftval=(leftval*-1)+"+Integer.toString(where_left-what_right-1)
					                        +", rightval=(rightval*-1)+"+Integer.toString(where_left-what_right-1) 
					                        +" where leftval<0");
			
			
			s.close();
			conn.commit();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void insert_before(String what, String where){
		try {
		int where_left = Integer.MIN_VALUE;
		
		Connection conn = tree.openConnection();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select leftval from sqltree where name='"+ where + "'");
		if (rs.next()) {
			where_left = rs.getInt(1);
		}
	
		
//		Bestehende Knotennummern um diff verschieben
		
		s.executeUpdate("update sqltree set leftval=leftval + 2 where leftval>="+where_left);
	    s.executeUpdate("update sqltree set rightval=rightval + 2 where rightval>"+where_left);

		s.execute("insert into sqltree values ('"+what+"',"+where_left+","+(int)(where_left+1)+")");		
		
		s.close();
		conn.commit();
		conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void insert_after(String what, String where){
		try {
		int where_right = Integer.MIN_VALUE;
		
		Connection conn = tree.openConnection();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select rightval from sqltree where name='"+ where + "'");
		if (rs.next()) {
			where_right = rs.getInt(1);
		}
	
		
//		Bestehende Knotennummern um diff verschieben
		
		s.executeUpdate("update sqltree set leftval=leftval + 2 where leftval>"+where_right);
	    s.executeUpdate("update sqltree set rightval=rightval + 2 where rightval>"+where_right);

		s.execute("insert into sqltree values ('"+what+"',"+(int)(where_right+1)+","+(int)(where_right+2)+")");		
		
		s.close();
		conn.commit();
		conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void insert_under(String what, String where){
		try {
		int where_right = Integer.MIN_VALUE;
		
		Connection conn = tree.openConnection();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select rightval from sqltree where name='"+ where + "'");
		if (rs.next()) {
			where_right = rs.getInt(1);
		}
	
		
//		Bestehende Knotennummern um diff verschieben
		
		s.executeUpdate("update sqltree set leftval=leftval + 2 where leftval>"+where_right);
	    s.executeUpdate("update sqltree set rightval=rightval + 2 where rightval>="+where_right);

		s.execute("insert into sqltree values ('"+what+"',"+where_right+","+(int)(where_right+1)+")");		
		
		s.close();
		conn.commit();
		conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public void debug(){
		tree.debug();
	}
	
	public boolean validateListInput(String formula){
		boolean result = true;
		result = result && formula.startsWith("("); 
		result = result && formula.endsWith(")");
		int depth=0;
		for(int i=0;i<formula.length();i++){
			String s = formula.substring(i,i+1);
			if(s.equals("(")){
				depth++;
			}
			if(s.equals(")")){
				result = result && depth>0;
				depth--;
			}
		}
		result = result && depth==0;
		
		return result;
		
	}
	
	public String getTreeAsListString(){
		String result="";
		try {
			
			Connection conn = tree.openConnection();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from sqltree order by leftval");
			Stack<Integer> parentRightValues = new Stack<Integer>();
			Stack<Integer> parentLeftValues = new Stack<Integer>();
			if (rs.next()) {
				//root node
				result = "("+rs.getString("name")+")";
				parentLeftValues.push(rs.getInt("leftval"));
				parentRightValues.push(rs.getInt("rightval"));
				
				
			}
			while(rs.next()){
				if(rs.getInt("leftval")-parentLeftValues.peek()==1){
					//new level
					parentLeftValues.push(rs.getInt("leftval"));
					parentRightValues.push(rs.getInt("rightval"));
				}
				while(rs.getInt("leftval")>parentRightValues.peek()+1){
					//move up
					parentLeftValues.pop();
					parentRightValues.pop();
				}
				
				result = result.substring(0, result.length()-(parentLeftValues.size()-1))
		         +"("+rs.getString("name")+")"
		         +result.substring(result.length()-(parentLeftValues.size()-1));
				
				if(rs.getInt("rightval")-rs.getInt("leftval")==1){
					//leaf node - nothing to do?
				}
				if(rs.getInt("leftval")-parentRightValues.peek()==1){
					//right sibling -> becomes new parent
					parentLeftValues.pop();
					parentLeftValues.push(rs.getInt("leftval"));
					parentRightValues.pop();
					parentRightValues.push(rs.getInt("rightval"));
					
				}

				
				
			}
			
			s.close();
			conn.commit();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean existsNode(String name){
		boolean result;
		try {
			
			Connection conn = tree.openConnection();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select name from sqltree where name='"+name+"'");
			result = rs.next();
			rs.close();
			s.close();
			conn.commit();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			result=false;
		}
		return result;
	}
	
	public void dropTree(){
		try {
			Connection conn = tree.openConnection();
			Statement s = conn.createStatement();
			s.execute("delete from sqltree where 1=1");
			s.close();
			conn.commit();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public SQLTree getSQLTree() {
		return tree;

	}
	
	
}
