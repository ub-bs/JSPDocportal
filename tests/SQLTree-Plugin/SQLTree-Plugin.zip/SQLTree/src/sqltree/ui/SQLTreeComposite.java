package sqltree.ui;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.draw2d.ScrollPane;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import sqltree.SQLTreeManager;
import sqltree.draw.SQLTreeDrawer;

public class SQLTreeComposite extends Composite implements SelectionListener {
	String lastOrder ="";
	Figure paintingContents;
	
	Text txtLastOrder, txtTreeAsList;
	Text txtCreate,txtInsertWhat, txtInsertWhere, txtMoveWhat, txtMoveWhere, txtDelete;
	Button btnCreate, btnInsertBefore, btnInsertAfter, btnInsertUnder, btnMoveBefore, btnMoveAfter, btnMoveUnder, btnDelete;
	Canvas paintingArea;
	SQLTreeManager sqlTreeMgr;
	public SQLTreeComposite(Composite parent, int style, SQLTreeManager mgr) {
		super(parent, style);
		sqlTreeMgr = mgr;
		GridLayout glThis = new GridLayout();
		glThis.numColumns=5;
		glThis.makeColumnsEqualWidth=true;
		this.setLayout(glThis);
		
		Label lblOrder = new Label(this, SWT.NONE);
		lblOrder.setText("Befehl: ");
		lblOrder.setLayoutData(new GridData());
		txtLastOrder = new Text(this, SWT.BORDER);
		txtLastOrder.setEditable(false);
		txtLastOrder.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 4,1));
		
		Label lblTreeAsList = new Label(this, SWT.NONE);
		lblTreeAsList.setText("Baum als Liste: ");
		lblTreeAsList.setLayoutData(new GridData());
		txtTreeAsList = new Text(this, SWT.BORDER);
		txtTreeAsList.setEditable(false);
		txtTreeAsList.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 4,1));
		
		paintingArea = new Canvas(this, SWT.BORDER);
		
		paintingArea.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true, 5,1));
		LightweightSystem lws = new LightweightSystem(paintingArea);
		
		paintingContents = new Figure();
		ScrollPane scrPane = new ScrollPane();
		scrPane.setContents(paintingContents);
		lws.setContents(scrPane);
		
		Group grpOrderCreate = new Group(this, SWT.NONE);
		grpOrderCreate.setText("CREATE");
		grpOrderCreate.setLayoutData(new GridData(SWT.FILL, SWT.FILL,true, false, 2,1));
		
		Group grpOrderInsert = new Group(this, SWT.NONE);
		grpOrderInsert.setText("INSERT");
		grpOrderInsert.setLayoutData(new GridData(SWT.FILL, SWT.FILL,true, false, 1,1));
		
		Group grpOrderMove = new Group(this, SWT.NONE);
		grpOrderMove.setText("MOVE");
		grpOrderMove.setLayoutData(new GridData(SWT.FILL, SWT.FILL,true, false, 1,1));
				
		Group grpOrderDelete = new Group(this, SWT.NONE);
		grpOrderDelete.setText("DELETE");
		grpOrderDelete.setLayoutData(new GridData(SWT.FILL, SWT.FILL,true, false, 1,1));
		
		//Group "Create"
		GridLayout glGrpOrderCreate = new GridLayout();
		glGrpOrderCreate.numColumns=2;
		grpOrderCreate.setLayout(glGrpOrderCreate);
		txtCreate = new Text(grpOrderCreate, SWT.BORDER|SWT.MULTI);
		GridData gdTxtCreate  = new GridData(SWT.FILL, SWT.NONE, true, false, 2,1);
		gdTxtCreate.heightHint= 2*txtCreate.computeSize(SWT.DEFAULT, SWT.DEFAULT).y;
		txtCreate.setLayoutData(gdTxtCreate);
		btnCreate = new Button(grpOrderCreate, SWT.PUSH);
		btnCreate.setText("Erzeugen");
		btnCreate.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 2,1 ));
		btnCreate.addSelectionListener(this);
		
		Text txtSample = new Text(grpOrderCreate, SWT.MULTI);
		txtSample.setEditable(false);
		txtSample.setText("z.B.: (A(B)(C(D)(E(G)(H(I)(K)(L)))(F)))\n(World(Europe(Germany)(UK)(France)(Spain))(Asia))");
		txtSample.setLayoutData(new GridData(SWT.LEFT, SWT.NONE, false, false,2,1));
		
		
		//Group "Insert"
		GridLayout glGrpOrderInsert = new GridLayout();
		glGrpOrderInsert.numColumns=2;
		grpOrderInsert.setLayout(glGrpOrderInsert);
		Label lblInsertWhat = new Label(grpOrderInsert, SWT.NONE);
		lblInsertWhat.setText("Was: ");
		lblInsertWhat.setLayoutData(new GridData());
		txtInsertWhat = new Text(grpOrderInsert, SWT.BORDER);
		txtInsertWhat.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false, 1,1));
		Label lblInsertWhere = new Label(grpOrderInsert, SWT.NONE);
		lblInsertWhere.setText("Wo: ");
		lblInsertWhere.setLayoutData(new GridData());
		txtInsertWhere = new Text(grpOrderInsert, SWT.BORDER);
		txtInsertWhere.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 1, 1));
		btnInsertBefore = new Button(grpOrderInsert, SWT.PUSH);
		btnInsertBefore.setText("Einf�gen vor");
		btnInsertBefore.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 2,1));
		btnInsertBefore.addSelectionListener(this);
		btnInsertAfter = new Button(grpOrderInsert, SWT.PUSH);
		btnInsertAfter.setText("Einf�gen nach");
		btnInsertAfter.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 2,1));
		btnInsertAfter.addSelectionListener(this);
		btnInsertUnder = new Button(grpOrderInsert, SWT.PUSH);
		btnInsertUnder.setText("Einf�gen unter");
		btnInsertUnder.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 2,1));
		btnInsertUnder.addSelectionListener(this);
		
		//Group "Move"
		GridLayout glGrpOrderMove = new GridLayout();
		glGrpOrderMove.numColumns=2;
		grpOrderMove.setLayout(glGrpOrderMove);
		Label lblMoveWhat = new Label(grpOrderMove, SWT.NONE);
		lblMoveWhat.setText("Was: ");
		lblMoveWhat.setLayoutData(new GridData());
		txtMoveWhat = new Text(grpOrderMove, SWT.BORDER);
		txtMoveWhat.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false, 1,1));
		Label lblMoveWhere = new Label(grpOrderMove, SWT.NONE);
		lblMoveWhere.setText("Wohin: ");
		lblMoveWhere.setLayoutData(new GridData());
		txtMoveWhere = new Text(grpOrderMove, SWT.BORDER);
		txtMoveWhere.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 1, 1));
		btnMoveBefore = new Button(grpOrderMove, SWT.PUSH);
		btnMoveBefore.setText("Verschieben vor");
		btnMoveBefore.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 2,1));
		btnMoveBefore.addSelectionListener(this);
		btnMoveAfter = new Button(grpOrderMove, SWT.PUSH);
		btnMoveAfter.setText("Verschieben nach");
		btnMoveAfter.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 2,1));
		btnMoveAfter.addSelectionListener(this);
		btnMoveUnder = new Button(grpOrderMove, SWT.PUSH);
		btnMoveUnder.setText("Verschieben unter");
		btnMoveUnder.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 2,1));
		btnMoveUnder.addSelectionListener(this);
		
		//Group Delete
		GridLayout glGrpOrderDelete = new GridLayout();
		glGrpOrderDelete.numColumns=2;
		grpOrderDelete.setLayout(glGrpOrderDelete);
		Label lblDeleteWhat = new Label(grpOrderDelete, SWT.NONE);
		lblDeleteWhat.setText("Was: ");
		lblDeleteWhat.setLayoutData(new GridData());
		txtDelete = new Text(grpOrderDelete, SWT.BORDER);
		txtDelete.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false, 1,1));
		Label lblDeleteSpace = new Label(grpOrderDelete, SWT.NONE);
		lblDeleteSpace.setLayoutData(new GridData(SWT.NONE, SWT.NONE,false, false, 2,1));
		btnDelete = new Button(grpOrderDelete, SWT.PUSH);
		btnDelete.setText("L�schen");
		btnDelete.setLayoutData(new GridData(SWT.FILL, SWT.NONE, false, false, 2,1));
		btnDelete.addSelectionListener(this);
		
		
		
	}
	

	
	private void updateUI(){
		txtLastOrder.setText(lastOrder);
		txtTreeAsList.setText(sqlTreeMgr.getTreeAsListString());
		SQLTreeDrawer.draw(sqlTreeMgr.getSQLTree(), paintingContents);
		
	}

	public void widgetDefaultSelected(SelectionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void widgetSelected(SelectionEvent e) {
		if(e.getSource().equals(btnCreate)){
			String s = txtCreate.getText().trim();
			if(sqlTreeMgr.validateListInput(s)){
				sqlTreeMgr.dropTree();
				sqlTreeMgr.parse(s);
				lastOrder = "CREATE "+s;
				updateUI();
			}
			else{
				MessageBox mb = new MessageBox(this.getShell(),SWT.OK);
				mb.setText("Syntaxfehler");
				mb.setMessage("Die Eingabe Formel ist fehlerhaft.\nLISP-Syntax verwenden:\nz.B.: (A(B(C(D)(E)))(F)))");
				mb.open();
			}
		}
		if(e.getSource().equals(btnDelete)){
			String s = txtDelete.getText();
			if(sqlTreeMgr.existsNode(s)){
				sqlTreeMgr.delete(s);
				lastOrder = "DELETE "+s;
				updateUI();
			}
			else{
				MessageBox mb = new MessageBox(this.getShell(),SWT.OK);
				mb.setText("Syntaxfehler");
				mb.setMessage("Im aktuellen Baum existiert kein Knoten "+s+".");
				mb.open();
			}
		}
		if(e.getSource().equals(btnMoveAfter)){
			String what = txtMoveWhat.getText();
			String where = txtMoveWhere.getText();
			if(sqlTreeMgr.existsNode(where) && sqlTreeMgr.existsNode(what)){
				sqlTreeMgr.move_after(what, where);
				lastOrder = "MOVE "+what+" AFTER "+where;
				updateUI();
			}
			else{
				MessageBox mb = new MessageBox(this.getShell(),SWT.OK);
				mb.setText("Syntaxfehler");
				mb.setMessage("Bitte geben Sie zwei Knotennamen ein.");
				mb.open();
			}
		}
		if(e.getSource().equals(btnMoveBefore)){
			String what = txtMoveWhat.getText();
			String where = txtMoveWhere.getText();
			if(sqlTreeMgr.existsNode(where) && sqlTreeMgr.existsNode(what)){
				sqlTreeMgr.move_before(what, where);
				lastOrder = "MOVE "+what+" BEFORE "+where;
				updateUI();
			}
			else{
				MessageBox mb = new MessageBox(this.getShell(),SWT.OK);
				mb.setText("Syntaxfehler");
				mb.setMessage("Bitte geben Sie zwei Knotennamen ein.");
				mb.open();
			}
		}
		if(e.getSource().equals(btnMoveUnder)){
			String what = txtMoveWhat.getText();
			String where = txtMoveWhere.getText();
			if(sqlTreeMgr.existsNode(where) && sqlTreeMgr.existsNode(what)){
				sqlTreeMgr.move_under(what, where);
				lastOrder = "MOVE "+what+" UNDER "+where;
				updateUI();
			}
			else{
				MessageBox mb = new MessageBox(this.getShell(),SWT.OK);
				mb.setText("Syntaxfehler");
				mb.setMessage("Bitte geben Sie zwei Knotennamen ein.");
				mb.open();
			}
		}
		if(e.getSource().equals(btnInsertBefore)){
			String what = txtInsertWhat.getText();
			String where = txtInsertWhere.getText();
			if(sqlTreeMgr.existsNode(where) && what.length()>0 && !sqlTreeMgr.existsNode(what)){
				sqlTreeMgr.insert_before(what, where);
				lastOrder = "INSERT "+what+" BEFORE "+where;
				updateUI();
			}
			else{
				MessageBox mb = new MessageBox(this.getShell(),SWT.OK);
				mb.setText("Syntaxfehler");
				mb.setMessage("Bitte geben Sie zwei Knotennamen ein.");
				mb.open();
			}
		}
		
		if(e.getSource().equals(btnInsertAfter)){
			String what = txtInsertWhat.getText();
			String where = txtInsertWhere.getText();
			if(sqlTreeMgr.existsNode(where) && what.length()>0 && !sqlTreeMgr.existsNode(what)){
				sqlTreeMgr.insert_after(what, where);
				lastOrder = "INSERT "+what+" AFTER "+where;
				updateUI();
			}
			else{
				MessageBox mb = new MessageBox(this.getShell(),SWT.OK);
				mb.setText("Syntaxfehler");
				mb.setMessage("Bitte geben Sie zwei Knotennamen ein.");
				mb.open();
			}
		}
		if(e.getSource().equals(btnInsertUnder)){
			String what = txtInsertWhat.getText();
			String where = txtInsertWhere.getText();
			if(sqlTreeMgr.existsNode(where) && what.length()>0 && !sqlTreeMgr.existsNode(what)){
				sqlTreeMgr.insert_under(what, where);
				lastOrder = "INSERT "+what+" UNDER "+where;
				updateUI();
			}
			else{
				MessageBox mb = new MessageBox(this.getShell(),SWT.OK);
				mb.setText("Syntaxfehler");
				mb.setMessage("Bitte geben Sie zwei Knotennamen ein.");
				mb.open();
			}
		}


		
	}
	

}
