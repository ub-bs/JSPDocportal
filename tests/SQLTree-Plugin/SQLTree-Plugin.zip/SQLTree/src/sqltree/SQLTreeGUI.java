package sqltree;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.draw2d.XYLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

import sqltree.draw.SQLTreeDrawer;
import sqltree.ui.SQLTreeComposite;

public class SQLTreeGUI {
	 public static void main(String args[]){
			
		 Display d = new Display();
			final Shell shell = new Shell(d);
			shell.setSize(800, 600);
			shell.setText("SQLTree GUI");
			shell.setLayout(new FillLayout());
			SQLTreeManager sqlTreeMgr = new SQLTreeManager();
			SQLTreeComposite cmp = new SQLTreeComposite(shell, SWT.BORDER, sqlTreeMgr);
			
			
			
	
			shell.open();
			while (!shell.isDisposed())
				while (!d.readAndDispatch())
					d.sleep();
		 }
}
